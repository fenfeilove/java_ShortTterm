function SQTJ_INIT() {
	SQTJ_doLoadTree();
	SQTJ_doLoadSearch();
//	SQTJ_doLoadGird();
//	SQTJ_doLoadChildGird();
}
var tree;
function SQTJ_doLoadTree() {
	var url = "sqtb/trees";
	var loader = dhtmlxAjax.getSync(url);
	// var obj = JSON.parse(loader);
	// alert(obj);
	// alert(loader.xmlDoc.responseText);
	var str = loader.xmlDoc.responseText;
	// alert(str);
	// var jsondata = {id:0 , item:[{id:"海堤",text:"海堤" ,item:[{id:"ab",
	// text:"child" ,item:[{id:3,text:"last"
	// ,item:[{id:4,text:"haha"},{id:5,text:"xixi"
	// ,item:[{id:6,text:"lala"},{id:6,text:"lala"},{id:6,text:"lala"}]}]}]}]},{id:2,
	// text:"middle", item:[{id:"21", text:"child"}]},{id:3,text:"last"}]};
	// var jsondata={id:0 ,
	// item:[{id:1,text:"集团1",item:[]},{id:2,text:"集团2",item:[]},{id:3,text:"集团3",item:[]}]};
	var jsondata = strToJson(str);
	// alert(jsondata);
	tree = new dhtmlXTreeObject("mytree", "100%", "100%", 0);
	tree.setSkin('dhx_skyblue');
	tree.setImagePath("dhtmlx/dhtmlxTree/codebase/imgs/csh_dhx_skyblue/");
	tree.enableCheckBoxes(false);
	tree.enableThreeStateCheckboxes(false);

	// var jsonList = jQuery.parseJSON(str);
	// jsonList.item=jsondata;

	tree.loadJSONObject(jsondata, function() {
		// alert("Your data has been loaded.");
	});
	tree.setOnClickHandler(SQTJ_treeonclick);
};
function strToJson(str) {
	var json = (new Function("return " + str))();
	return json;
}
function SQTJ_treeonclick(id) {
	var itemId = id;
	if (tree.hasChildren(itemId)) {
		if (tree.getOpenState(itemId) == "1") {
			tree.closeItem(itemId);
		} else {
			tree.openItem(itemId);
		}
	} else {
		alert(id);
	}
};
function SQTJ_doLoadSearch() {
	var searchForm, searchData;
	searchData = [ {
		type : "settings",
		position : "label-top",
		labelWidth : 80,
		inputWidth : 120
	}, {
		type : "fieldset",
		label : "快速查询",
		labelWidth : 80,
		inputWidth : "auto",
		list : [ {
			type : "input",
			name : "pk_group",
			label : "发行单位"
		}, {
			type : "input",
			name : "pk_org",
			label : "集团"
		}, {
			type : "input",
			name : "status",
			label : "审核状态",
		}, {
			type : "button",
			name : "Submit",
			value : "确定"
		} ]
	} ];
	searchForm = new dhtmlXForm("mysearch", searchData);
	searchForm.attachEvent("onButtonClick", function(button_id) {
		if (button_id == "Submit") {
			// LoginForm.disableItem("Submit");
			// alert("submit");
			var url = "login/check";
			searchForm.send(url, function(loader, response) {
				alert(response);
			});
		} else if (button_id == "Reset") {
			LoginForm.clear();
		}
	});
}
function SQTJ_doLoadGird() {
	var mygrid;
	mygrid = new dhtmlXGridObject('mygrid');
	mygrid.setImagePath("dhtmlx/dhtmlxGrid/codebase/imgs/"); // 指定图片路径
	mygrid.setHeader("序号,申请单号,发行单位,所属集团,债券余额,单据状态,批复文号"); // 设置表头显示
	mygrid.setInitWidths("100,100,100,100,100,100,100");
	mygrid.setColTypes("ro,ro,ro,ro,ro,ro,ro");
	mygrid.setColAlign("left,center,center,center,center,center,center");
	mygrid.enablePaging(true, 20, 5, "pagingArea", true, "recinfoArea");
	mygrid.setPagingSkin("bricks");
	// mygrid.setSkin("dhx_skyblue");
	mygrid.init();
	mygrid.setSkin("dhx_terrace");
	// var combo=mygrid.getCombo(3);//码表
	// combo.put("0","公司");
	// combo.put("1","部门");
	// {row:[{id:"5",data:["null","公司4","集团2","未审核"]}]}
	// var data = {
	// rows : [ {
	// id : 1,
	// data : [ "12","A Time to Kill", "John Grisham", "100" ]
	// }, {
	// id : 2,
	// data : [ "12","Blood and Smoke", "Stephen King", "1000" ]
	// }, {
	// id : 3,
	// data : [ "12","The Rainmaker", "John Grisham", "-200" ]
	// }, {
	// id: "5",
	// data : ["null","公司4","集团2","未审核"]
	// } ]
	// };
	var url = "sqtb/search"
	var loader = dhtmlxAjax.getSync(url);
	var str = loader.xmlDoc.responseText;
	var jsondata = strToJson(str);
	mygrid.parse(jsondata, function() {
		// alert(1);
	}, "json");

	mygrid.attachEvent("onRowDblClicked", function(id, ind) {
		open_windows_EditDept(id);
	});
	mygrid.selectRow(0);

}
function SQTJ_doLoadChildGird() {
	var mychildgrid;
	mychildgrid = new dhtmlXGridObject('mychildgrid');
	mychildgrid.setImagePath("dhtmlx/dhtmlxGrid/codebase/imgs/"); // 指定图片路径
	mychildgrid.setHeader("序号,组织机构编码,组织机构名称,类型"); // 设置表头显示
	mychildgrid.setInitWidths("100,100,100,100"); 
	mychildgrid.setColTypes("ro,ro,ro,ro");
	mychildgrid.setColAlign("center,center,center,center"); 
	var url = "";
	mychildgrid.enablePaging(true, 5, 5, "childpagingArea", true,
			"childrecinfoArea");
	mychildgrid.setPagingSkin("bricks");
	mychildgrid.init();
	//不知为何码表无效
	var combo=mychildgrid.getCombo(0);//码表
	combo.put("null","");
	mychildgrid.setSkin("dhx_terrace");
	// mychildgrid.loadXML(url);
	var url = "sqtb/search"
//	var loader = dhtmlxAjax.getSync(url);
//	var str = loader.xmlDoc.responseText;
//	var jsondata = strToJson(str);
//	mychildgrid.parse(jsondata, function() {
//		// alert(1);
//	}, "json");
	mychildgrid.load(url,"json");
	mychildgrid.attachEvent("onRowDblClicked", function(id, ind) {
		open_windows_EditDept(id);
	});
	mychildgrid.selectRow(0);

}
